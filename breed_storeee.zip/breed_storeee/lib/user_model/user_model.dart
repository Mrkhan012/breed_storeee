class UserModel {
  String userId;
  String username;
  String email;
  String password;
  String address;

  UserModel({
    required this.userId,
    required this.username,
    required this.email,
    required this.password,
    required this.address,

});

  Map<String, dynamic> toMap(){
    return {
      "_userId": userId,
      "_username": username,
      "_email": email,
      "_password": password,
      "_address": address,


    };
  }

  factory UserModel.fromMap(Map<String, dynamic>map){
    return UserModel(
        userId: map["_userId"],
        username: map["_username"],
        email: map["_email"],
        password: map["_password"],
        address:map["_address"],
    );
  }
}