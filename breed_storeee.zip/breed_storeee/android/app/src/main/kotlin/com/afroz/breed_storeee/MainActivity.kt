package com.afroz.breed_storeee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
